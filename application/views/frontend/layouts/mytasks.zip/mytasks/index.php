<h4 class="mb-4 font-bold text-gray-800 dark:text-gray-100"><?php echo $title; ?></h4>

<?php 
// --- DATA SIMULASI (Ganti dengan data dari Controller/Model Anda) ---
$summary = [
    'total' => 50, 'sukses' => 35, 'gagal_buruk' => 5, 'pending' => 10, 'grup_aktif' => 1
];
// Anda harus mendapatkan variabel $task_summary dari Controller MyTasks
// Untuk sementara, kita gunakan array $summary di atas.
$task_summary = $summary;

$persen_selesai = ($task_summary['total'] > 0) ? round($task_summary['sukses'] / $task_summary['total'] * 100) : 0;
?>

<?php if ($this->session->flashdata('success')): ?>
    <div class="alert alert-success bg-green-100 text-green-800 p-3 rounded mb-4"><i class="fa fa-check-circle mr-2"></i> <?php echo $this->session->flashdata('success'); ?></div>
<?php endif; ?>
<?php if ($this->session->flashdata('error')): ?>
    <div class="alert alert-danger bg-red-100 text-red-800 p-3 rounded mb-4"><i class="fa fa-times-circle mr-2"></i> <?php echo $this->session->flashdata('error'); ?></div>
<?php endif; ?>

<div class="row mb-5">
    
    <div class="col-md-6 col-xl-3">
        <div class="card bg-c-blue order-card">
            <div class="card-block">
                <h6 class="m-b-20">Total Tugas Saya</h6>
                <h2 class="text-right"><i class="fa fa-list f-left"></i><span><?php echo $task_summary['total']; ?></span></h2>
                <p class="m-b-0">Progres Selesai<span class="f-right"><?php echo $persen_selesai; ?>%</span></p>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 col-xl-3">
        <div class="card bg-c-green order-card">
            <div class="card-block">
                <h6 class="m-b-20">Tugas Sukses</h6>
                <h2 class="text-right"><i class="fa fa-check-circle f-left"></i><span><?php echo $task_summary['sukses']; ?></span></h2>
                <p class="m-b-0">Sisa Pending<span class="f-right"><?php echo $task_summary['pending']; ?></span></p>
            </div>
        </div>
    </div>
    
    <div class="col-md-6 col-xl-3">
        <div class="card bg-c-pink order-card">
            <div class="card-block">
                <h6 class="m-b-20">Tugas Buruk/Gagal</h6>
                <h2 class="text-right"><i class="fa fa-times f-left"></i><span><?php echo $task_summary['gagal_buruk']; ?></span></h2>
                <p class="m-b-0">Perlu Tindak Lanjut<span class="f-right"><?php echo $task_summary['gagal_buruk']; ?></span></p>
            </div>
        </div>
    </div>

    <div class="col-md-6 col-xl-3">
        <div class="card bg-c-yellow order-card">
            <div class="card-block">
                <h6 class="m-b-20">Grup Aktif Saat Ini</h6>
                <h2 class="text-right"><i class="fa fa-plane f-left"></i><span><?php echo $task_summary['grup_aktif']; ?></span></h2>
                <p class="m-b-0">Grup Sedang Berjalan<span class="f-right"><?php echo $task_summary['grup_aktif']; ?></span></p>
            </div>
        </div>
    </div>
</div>
<h5 class="mb-3 font-bold text-gray-800 dark:text-gray-100">Daftar Tugas Harian</h5>

<?php if (empty($grouped_tasks)): ?>
    <div class="card text-center py-5 shadow-lg">
        <div class="card-body">
            <h5 class="card-title text-muted">🎉 Semua tugas selesai atau belum ada penugasan yang aktif.</h5>
            <p>Silakan tunggu instruksi selanjutnya dari Admin.</p>
        </div>
    </div>
<?php else: ?>

    <?php foreach ($grouped_tasks as $grup_id => $grup_data): ?>
        <div class="card mb-4 shadow-lg border-0">
            <div class="card-header card-gradient-primary border-0 rounded-t-lg p-3">
                <i class="fa fa-plane mr-2"></i> Grup: **<?php echo $grup_data['nama_grup']; ?>**
            </div>
            <div class="card-body p-0">
                <div class="accordion" id="accordionGrup<?php echo $grup_id; ?>">
                    <?php $i = 0; foreach ($grup_data['tugas_per_tanggal'] as $tgl => $tasks): $i++; ?>
                        <div class="card mb-0 border-0">
                            <div class="card-header p-0 border-b border-gray-200 dark:border-gray-700" id="heading<?php echo $grup_id . $i; ?>">
                                <h2 class="mb-0">
                                    <button class="btn btn-block text-left py-3 px-4 d-flex justify-content-between align-items-center bg-white dark:bg-themedark-cardbg" type="button" data-toggle="collapse" data-target="#collapse<?php echo $grup_id . $i; ?>" aria-expanded="<?php echo $i === 1 ? 'true' : 'false'; ?>">
                                        <i class="fa fa-calendar-alt mr-2"></i> Tanggal: **<?php echo date('d M Y', strtotime($tgl)); ?>**
                                        <span class="badge badge-secondary"><?php echo count($tasks); ?> Tugas</span>
                                    </button>
                                </h2>
                            </div>

                            <div id="collapse<?php echo $grup_id . $i; ?>" class="collapse <?php echo $i === 1 ? 'show' : ''; ?>" aria-labelledby="heading<?php echo $grup_id . $i; ?>" data-parent="#accordionGrup<?php echo $grup_id; ?>">
                                <div class="card-body p-0">
                                    <ul class="list-group list-group-flush">
                                        <?php foreach ($tasks as $task): ?>
                                            <li class="list-group-item d-flex justify-content-between align-items-center text-sm px-4 py-3">
                                                <div>
                                                    <?php 
                                                        $status_class = ['Pending' => 'secondary', 'Sukses' => 'success', 'Cukup' => 'info', 'Buruk' => 'warning', 'Gagal' => 'danger'];
                                                        $status_icon = ['Pending' => 'clock', 'Sukses' => 'check', 'Cukup' => 'info', 'Buruk' => 'exclamation', 'Gagal' => 'times'];
                                                    ?>
                                                    <span class="badge badge-<?php echo $status_class[$task->status]; ?> mr-2">
                                                        <i class="fa fa-<?php echo $status_icon[$task->status]; ?>"></i> <?php echo $task->status; ?>
                                                    </span>
                                                    
                                                    **<?php echo $task->deskripsi; ?>**
                                                    
                                                    <?php if ($task->foto_bukti): ?>
                                                        <a href="<?php echo base_url($task->foto_bukti); ?>" target="_blank" class="text-primary ml-2"><i class="fa fa-camera"></i></a>
                                                    <?php endif; ?>
                                                </div>
                                                
                                                <?php if ($task->tipe_item == 'checklist'): ?>
                                                    <button type="button" class="btn btn-sm btn-outline-primary" 
                                                            data-toggle="modal" 
                                                            data-target="#updateModal"
                                                            data-id="<?php echo $task->id; ?>"
                                                            data-desc="<?php echo $task->deskripsi; ?>"
                                                            data-status="<?php echo $task->status; ?>"
                                                            data-foto="<?php echo $task->foto_bukti ? base_url($task->foto_bukti) : ''; ?>"
                                                            data-old-foto-path="<?php echo $task->foto_bukti; ?>">
                                                        <i class="fa fa-edit"></i> Aksi
                                                    </button>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>


<div class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header card-gradient-primary text-white border-0">
                <h5 class="modal-title" id="updateModalLabel">Update Tugas: <span id="task_description"></span></h5>
                <button type="button" class="close text-white opacity-80" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?php echo form_open_multipart('mytasks/update_task'); ?>
                <div class="modal-body">
                    <input type="hidden" name="grup_item_id" id="modal_grup_item_id">
                    <input type="hidden" name="old_foto_path" id="modal_old_foto_path">

                    <div class="form-group mb-3">
                        <label for="status">Status Eksekusi Wajib Dipilih</label>
                        <select name="status" id="modal_status" class="form-control" required>
                            <option value="Sukses">Sukses</option>
                            <option value="Cukup">Cukup</option>
                            <option value="Buruk">Buruk</option>
                            <option value="Gagal">Gagal</option>
                        </select>
                        <small class="form-text text-danger">Status **Buruk** atau **Gagal** akan memicu notifikasi real-time ke Admin!</small>
                    </div>

                    <div class="form-group mb-3">
                        <label>Foto Bukti (Maks. 5MB)</label>
                        <input type="file" name="foto_bukti" class="form-control-file">
                        <small class="form-text text-muted">Anda dapat mengupload foto baru atau membiarkannya kosong.</small>
                    </div>
                    
                    <div id="current_foto_preview" class="mb-3 p-2 border rounded" style="display:none;">
                        <label class="font-medium">Foto Bukti Saat Ini:</label>
                        <img id="foto_preview_img" src="" class="img-fluid border rounded" alt="Foto Bukti" style="max-height: 150px; width: 100%; object-fit: cover;">
                    </div>

                </div>
                <div class="modal-footer border-t border-gray-200 dark:border-gray-700">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary bg-primary-500 hover:bg-primary-600">Simpan Aksi</button>
                </div>
            <?php echo form_close(); ?>
        </div>
    </div>
</div>

<script>
    $('#updateModal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        var id = button.data('id');
        var desc = button.data('desc');
        var status = button.data('status');
        var foto_url = button.data('foto');
        var old_foto_path = button.data('old-foto-path');
        
        var modal = $(this);
        modal.find('#modal_grup_item_id').val(id);
        modal.find('#modal_old_foto_path').val(old_foto_path);
        modal.find('#task_description').text(desc);
        modal.find('#modal_status').val(status); 
        
        if (foto_url) {
            modal.find('#foto_preview_img').attr('src', foto_url);
            modal.find('#current_foto_preview').show();
        } else {
            modal.find('#current_foto_preview').hide();
        }
    });
</script>